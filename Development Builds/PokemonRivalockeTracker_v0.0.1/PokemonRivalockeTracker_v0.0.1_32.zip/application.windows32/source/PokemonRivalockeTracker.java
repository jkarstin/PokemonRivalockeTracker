import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class PokemonRivalockeTracker extends PApplet {

/* PokemonRivalockeTracker.pde
 * 
 * Main file of the program. This is where the magic happens.
 * Contains the two most important functions in the whole application: setup() and draw()
 * Naming restriction forces this file to be named the same as the folder it is saved within,
 * otherwise it will not run correctly during development and compilation.
 * 
 * See code for more detailed commenting on execution process.
 * 
 * J Karstin Neill    08.13.18
 */

//Declare Tiles
Menu mainMenu;
Menu playerMenu;
Label spotlightWelcomeLabel;
Label playerCreationWelcomeLabel;
Label teamsWelcomeLabel;

//Declare Pages
Page spotlightPage;
Page playersPage;
Page playerCreationPage;
Page teamsPage;
Page currentPage;

//Runs once at the beginning of the application
//Similar to the "int main()" function in C++ programs
public void setup() {
  //Set boundaries of the window size (width and height in number of pixels)
  //This is the size of the draw-able area inside the application window, not including the header bar at the top of the window
  //Dimensions of the window size are stored in system variables named "width" and "height," which can be accessed at any time
  
  
  //Initialize Page variables
  spotlightPage = new Page("SPOTLIGHT");
  playersPage   = new Page("PLAYERS");
  playerCreationPage = new Page("PLAYER CREATION");
  teamsPage     = new Page("TEAMS");
  
  //Intialize Tile variables
  mainMenu = new Menu(width-100, 10, 100, 310);
  playerMenu = new Menu(80, 80, width-260, height-160);
  spotlightWelcomeLabel      = new Label(new Coord(20, 20), new Coord(350, 30), "Welcome to the SPOTLIGHT Page!");
  playerCreationWelcomeLabel = new Label(new Coord(20, 20), new Coord(350, 30), "Future PLAYER CREATION Page, coming soon!");
  teamsWelcomeLabel          = new Label(new Coord(20, 20), new Coord(350, 30), "Future TEAMS Page, coming soon!");
  
  //Populate menus
  mainMenu.addPage(spotlightPage);
  mainMenu.addPage(playersPage);
  mainMenu.addPage(teamsPage);
  playerMenu.addPage(playerCreationPage);
  
  //Populate pages
  spotlightPage.addTile(spotlightWelcomeLabel);
  spotlightPage.addMenu(mainMenu);
  playersPage.addMenu(playerMenu);
  playersPage.addMenu(mainMenu);
  playerCreationPage.addTile(playerCreationWelcomeLabel);
  playerCreationPage.addMenu(mainMenu);
  teamsPage.addTile(teamsWelcomeLabel);
  teamsPage.addMenu(mainMenu);
  
  //Set starting value of currentPage
  currentPage = spotlightPage;
}

//Called once each time a mouse button is pressed down and then released
//Isn't called until the mouse button has been released
public void mouseClicked() {
  //Click Menu buttons
  Menu currentMenu;
  Button currentButton;
  for (int m=0; currentPage.getMenu(m) != null; m++) {
    currentMenu = currentPage.getMenu(m);
    for (int b=0; currentMenu.getButton(b) != null; b++) {
      currentButton = currentMenu.getButton(b);
      if (currentButton.click(mouseX, mouseY)) currentPage = currentMenu.getPage(b);
    }
  }
}

//Runs once every cycle (aka frame) of the program's execution
//Used to draw shapes and text to the screen
public void draw() {
  //Fill the whole screen with the color black, drawing over anything that happened in the previous frame
  //Essentially a fresh slate for the next frame's drawing actions
  background(127);
  //Show the contents of the current Page
  currentPage.show();
  //Hover over Menu buttons
  for (int m=0; currentPage.getMenu(m) != null; m++) {
    for (int b=0; currentPage.getMenu(m).getButton(b) != null; b++) {
      currentPage.getMenu(m).getButton(b).hover(mouseX, mouseY);
    }
  }
}
/* Battle.pde
 * 
 * Stores information about a Player vs Player battle.
 * Saves information about the battle as a snapshot of the moment the battle took place.
 * Any future updates to Players involved in the battle will not be
 * reflected in the battle's info, unless it is manually changed.
 * 
 * J Karstin Neill    08.11.18
 */

//Class defintion
public class Battle {
  //Private member variables
  private Gym mGym;
  private Player mWinner;
  private Player mLoser;
  private Team mWinningTeam;
  private Team mLosingTeam;
  
  //Constructor method
  public Battle(Gym gym, Player player1, Player player2, boolean player1won) {
    mGym = gym;
    //If player1won is true, player1 argument passed to the constructor is the winner, and player2 is the loser
    if (player1won) {
      mWinner = player1;
      mLoser = player2;
    }
    //Otherwise player1 is the loser, and player2 is the winner
    else {
      mWinner = player2;
      mLoser = player1;
    }
    //Save copies of the winning and losing Teams
    mWinningTeam = mWinner.copyTeam();
    mLosingTeam = mLoser.copyTeam();
  }
  
  //Get Gym where the battle took place
  public Gym gym() {
    return mGym;
  }
  
  //Get Player who won the battle
  public Player winner() {
    return mWinner;
  }
  
  //Get Player who lost the battle
  public Player loser() {
    return mLoser;
  }
  
  //Get copy of the Team of the winning Player at the time the battle took place
  public Team winningTeam() {
    return mWinningTeam;
  }
  
  //Get copy of the Team of the losing Player at the time the battle took place
  public Team losingTeam() {
    return mLosingTeam;
  }
  
  //Get a generated String summarizing the details of the battle
  public String summary() {
    String output = "";
    
    output += "GYM: " + mGym.name() + "\n";
    output += "PLAYERS: " + mWinner.name() + " VS " + mLoser.name() + "\n";
    output += "WINNER: " + mWinner.name() + " !!!\n";
    
    return output;
  }
};
/* Button.pde
 * 
 * J Karstin Neill    08.13.18
 */

public class Button extends Label {
  public Button(float x, float y, float w, float h) {
    super(new Coord(x, y), new Coord(w, h));
  }
  
  public void hover(Coord position) {
    if (contains(position)) mFillColor = color(150);
    else mFillColor = color(255);
  }
  
  public void hover(float x, float y) {
    this.hover(new Coord(x, y));
  }
  
  public boolean click(Coord position) {
    return contains(position);
  }
  
  public boolean click(float x, float y) {
    return click(new Coord(x, y));
  }
  
  private boolean contains(Coord position) {
    if (position.x() >= mPos.x() &&
        position.x() <= mPos.x()+mSize.x() &&
        position.y() >= mPos.y() &&
        position.y() <= mPos.y()+mSize.y()) {
      return true;
    }
    return false;
  }
};
/* Collection.pde
 * 
 * List/Queue/Stack structure designed to make manipulation and organization of large
 * groups of Tile instances and Tile children instances easier to manage.
 * 
 * Uses Tile as "maximum parent" value for generic type.
 * The mElement array is thus populated by Tile objects,
 * and adding/getting uses typecasting to type T to give an outward generic type usage.
 * 
 * J Karstin Neill    08.13.18
 */

public class Collection<E extends Tile> {
  private Tile[] mElements;
  private int mSpace;
  private int mCount;
  private int mMax;
  
  public Collection() {
    mSpace = 1;
    mElements = new Tile[mSpace];
    mElements[0] = null;
    mCount = 0;
    mMax = 0; //If mMax is set to zero, then no maximum exists
  }
  
  public Collection(int max) {
    mSpace = 1;
    mElements = new Tile[mSpace];
    mElements[0] = null;
    mCount = 0;
    mMax = max;
  }
  
  public int count() {
    return mCount;
  }
  
  public int space() {
    return mSpace;
  }
  
  public void addElement(E element) {
    if (mMax > 0 && mCount >= mMax) return;
    if (mCount >= mSpace) grow();
    mElements[mCount++] = element;
  }
  
  public void pushElement(E element) {
    //Place new element as index 0, and shift all others up one index
  }
  
  public E getElement(int index) {
    if (index < mCount) return (E)mElements[index];
    return null;
  }
  
  public E removeElement(int index) {
    E element = this.getElement(index);
    if (element != null) {
      Tile[] tmp = new Tile[mSpace];
      for (int i=0; i < mCount; i++) {
        if (i < index) tmp[i] = mElements[i];
        else if (i > index) tmp[i-1] = mElements[i];
        else continue;
      }
      mElements = tmp;
      tmp = null;
      mCount--;
    }
    return element;
  }
  
  private void grow() {
    int newSpace = mSpace*2;
    if (mMax > 0 && newSpace > mMax) newSpace = mMax;
    
    Tile[] tmp = new Tile[newSpace];
    for (int i=0; i < newSpace; i++) {
      if (i < mSpace) tmp[i] = mElements[i];
      else tmp[i] = null;
    }
    mElements = tmp;
    tmp = null;
    mSpace = newSpace;
  }
};
/* Coord.pde
 * 
 * The skeletal system of the entire program. A(n) (ideally) comprehensive base
 * structure to allow all program components to communicate and manipulate location and dimension.
 * 
 * J Karstin Neill    08.11.18
 */

public class Coord {
  float mX, mY;
  
  public Coord() {
    mX = 0;
    mY = 0;
  }
  
  public Coord(Coord other) {
    mX = other.x();
    mY = other.y();
  }
  
  public Coord(float x, float y) {
    mX = x;
    mY = y;
  }
  
  public void setX(float x) {
    mX = x;
  }
  
  public void setY(float y) {
    mY = y;
  }
  
  public float x() {
    return mX;
  }
  
  public float y() {
    return mY;
  }
  
  public Coord negate() {
    return this.times(-1);
  }
  
  public Coord plus(Coord other) {
    if (other != null) return new Coord(this.x() + other.x(), this.y() + other.y());
    return null;
  }
  
  public Coord minus(Coord other) {
    return this.plus(other.negate());
  }
  
  public void plusEq(Coord other) {
    if (other != null) {
      this.mX += other.x();
      this.mY += other.y();
    }
  }
  
  public Coord times(float mult) {
    return new Coord(this.mX*mult, this.mY*mult);
  }
  
  public Coord getCopy() {
    return new Coord(mX, mY);
  }
  
  public void cap(Coord TL, Coord BR) {
    //Minimum cap
    if (this.x() < TL.x()) this.mX = TL.x();
    if (this.y() < TL.y()) this.mY = TL.y();
    //Maximum cap
    if (this.x() > BR.x()) this.mX = BR.x();
    if (this.y() > BR.y()) this.mY = BR.y();
  }
  
  public void wrap(Coord TL, Coord BR) {
    //Minimum wrap to maximum
    if (this.x() < TL.x()) this.mX = BR.x()-(TL.x()-this.x());
    if (this.y() < TL.y()) this.mY = BR.y()-(TL.y()-this.y());
    //Maximum warp to minimum
    if (this.x() > BR.x()) this.mX = TL.x()+(this.x()-BR.x());
    if (this.y() > BR.y()) this.mY = TL.y()+(this.y()-BR.y());
  }
};
/* Gym.pde
 * 
 * 
 * J Karstin Neill    08.11.18
 */
 
public class Gym {
  private final static int MAXPLAYERS = 8;
  
  private String mName;
  private Player[] mPlayersInOrder;
  private int mPlayerCount;
  
  public Gym(String name) {
    mName = name;
    mPlayersInOrder = new Player[MAXPLAYERS];
    mPlayerCount = 0;
  }
  
  public void addPlayer(Player player) {
    if (mPlayerCount < MAXPLAYERS) {
      mPlayersInOrder[mPlayerCount++] = player;
    }
  }
  
  public String name() {
    return mName;
  }
  
  public Player first() {
    if (mPlayerCount > 0) return mPlayersInOrder[0];
    return null;
  }
};
/* Label.pde
 * 
 * 
 * J Karstin Neill    08.13.18
 */

public class Label extends Tile {
  private String mText;
  private int mTextColor;
  
  public Label() {
    super();
    mText = "";
    mFillColor = color(255);
    mTextColor = color(0);
  }
  
  public Label(Coord position, Coord size) {
    super(position, size);
    mText = "";
    mFillColor = color(255);
    mTextColor = color(0);
  }
  
  public Label(Coord position, Coord size, String text) {
    super(position, size);
    mText = text;
    mFillColor = color(255);
    mTextColor = color(0);
  }
  
  public void setTextColor(int textColor) {
    mTextColor = textColor;
  }
  
  public void setText(String text) {
    mText = text;
  }
  
  public void show() {
    super.show();
    fill(mTextColor);
    text(mText, mPos.x()+10, mPos.y()+20);
  }
};
/* Menu.pde
 * 
 * A tile child designed to link buttons to pages to make page selection interactive.
 * 
 * J Karstin Neill    08.13.18
 */

public class Menu extends Tile {
  private final static int MAXPAGES = 6;
  private Collection<Button> mButtons;
  private Collection<Page>   mPages;
  
  public Menu(float x, float y, float w, float h) {
    super(x, y, w, h);
    mFillColor = color(127);
    mButtons = new Collection<Button>(MAXPAGES);
    mPages   = new Collection<Page>(MAXPAGES);
  }
  
  //Create a button for the page, and add the page and its corresponding button to the collections
  public void addPage(Page page) {
    int currentPageIndex = mPages.count();
    Button tmp = new Button(mPos.x()+10, mPos.y()+10+50*currentPageIndex, mSize.x()-20, 40);
    tmp.setText(page.name());
    mButtons.addElement(tmp);
    mPages.addElement(page);
  }
  
  public void move(Coord delta) {
    super.move(delta);
    for (int b=0; mButtons.getElement(b) != null; b++) mButtons.getElement(b).move(delta);
  }
  
  public Button getButton(int index) {
    return mButtons.getElement(index);
  }
  
  public Page getPage(int index) {
    return mPages.getElement(index);
  }
  
  public void show() {
    super.show();
    for (int b=0; mButtons.getElement(b) != null; b++) {
      mButtons.getElement(b).show();
    }
  }
};
/* Page.pde
 * 
 * 
 * J Karstin Neill    08.13.18
 */

public class Page extends Tile {
  private final static int MAXTILES = 32;
  private final static int MAXMENUS = 8;
  
  private Collection<Tile> mTiles;
  private Collection<Menu> mMenus;
  private String mName;
  
  public Page(String name) {
    super(0, 0, width-1, height-1);
    mTiles = new Collection<Tile>(MAXTILES);
    mMenus = new Collection<Menu>(MAXMENUS);
    mName = name;
  }
  
  public String name() {
    return mName;
  }
  
  public Menu getMenu(int index) {
    return mMenus.getElement(index);
  }
  
  //Adds given menu to both menu collection and tile collection
  public void addMenu(Menu menu) {
    mMenus.addElement(menu);
    this.addTile(menu);
  }
  
  //Adds given generic tile to tile collection
  public void addTile(Tile tile) {
    mTiles.addElement(tile);
  }
  
  public void show() {
    super.show();
    for (int t=0; mTiles.getElement(t) != null; t++) {
      mTiles.getElement(t).show();
    }
  }
};
/* Player.pde
 * 
 * 
 * J Karstin Neill    08.11.18
 */

public class Player {
  private String mName;
  private Team mTeam;
  
  public Player(String name) {
    mName = name;
    mTeam = new Team();
  }
  
  public String name() {
    return mName;
  }
  
  public Team team() {
    return mTeam;
  }
  
  public Team copyTeam() {
    Team copy = new Team();
    for (int p=0; mTeam.getPokemon(p) != null; p++) {
      Pokemon tmp = mTeam.getPokemon(p);
      copy.addPokemon(new Pokemon(tmp.name(), tmp.breed(), tmp.type(), tmp.gender(), tmp.level()));
    }
    return copy;
  }
};
/* Pokemon.pde
 * 
 * 
 * J Karstin Neill    08.11.18
 */

public class Pokemon {
  private String mName;
  private String mType;
  private String mBreed;
  private String mGender;
  private int mLevel;
  
  public Pokemon(String name, String breed, String type, String gender, int level) {
    mName = name;
    mBreed = breed;
    mType = type;
    mGender = gender;
    mLevel = level;
  }
  
  public String name() {
    return mName;
  }
  
  public void changeName(String newName) {
    mName = newName;
  }
  
  public String breed() {
    return mBreed;
  }
  
  public void changeBreed(String newBreed) {
    mBreed = newBreed;
  }
  
  public String type() {
    return mType;
  }
  
  public void changeType(String newType) {
    mType = newType;
  }
  
  public String gender() {
    return mGender;
  }
  
  //public void changeGender(String newName) {
  //  mName = newName;
  //}
  
  public int level() {
    return mLevel;
  }
  
  public void changeLevel(int newLevel) {
    mLevel = newLevel;
  }
};
/* Team.pde
 * 
 * 
 * J Karstin Neill    08.11.18
 */

public class Team {
  private final static int MAXPOKEMON = 6;
  
  private Pokemon[] mPokemon;
  private int mPokemonCount;
  
  public Team() {
    mPokemon = new Pokemon[MAXPOKEMON];
    mPokemonCount = 0;
  }
  
  public void addPokemon(Pokemon pokemon) {
    if (mPokemonCount < MAXPOKEMON) {
      mPokemon[mPokemonCount++] = pokemon;
    }
  }
  
  public Pokemon getPokemon(int index) {
    if (index < mPokemonCount) return mPokemon[index];
    return null;
  }
};
/* Tile.pde
 * 
 * This is the base visualization component of the program.
 * Everything that will be drawn to the screen will be either
 * an instance of the Tile class, or an instance of one of the Tile class's children classes.
 * 
 * This provides a uniform way to handle position and size manipulation of every on-screen
 * component. Every class that "extends Tile" will be moveable, and resizable using the same class methods.
 * 
 * To call this class's constructor from a child's constructor, use the built-in method super().
 * 
 * J Karstin Neill    08.12.18
 */

public class Tile {
  //Protected fields
  protected Coord mPos;
  protected Coord mSize;
  
  protected int mFillColor;
  protected int mBorderColor;
  
  //Public constructor methods
  public Tile() {
    mPos  = new Coord();
    mSize = new Coord();
    mFillColor   = color(0);
    mBorderColor = color(0);
  }
  public Tile(float x, float y, float w, float h) {
    mPos  = new Coord(x, y);
    mSize = new Coord(w, h);
    mFillColor   = color(0);
    mBorderColor = color(0);
  }
  public Tile(Coord position, Coord size) {
    mPos  = position.getCopy();
    mSize =     size.getCopy();
    mFillColor   = color(0);
    mBorderColor = color(0);
  }
  
  public Coord pos() {
    return mPos;
  }
  
  public float x() {
    return mPos.x();
  }
  
  public float y() {
    return mPos.y();
  }
  
  public Coord dim() {
    return mSize;
  }
  
  public float width() {
    return mSize.x();
  }
  
  public float height() {
    return mSize.y();
  }
  
  //Adds given delta coordinate to this tile's position coordinate to simulate movement
  public void move(Coord delta) {
    mPos.plusEq(delta);
    mPos.wrap(mSize.negate(), new Coord(width, height));
  }
  
  //Wrapper method for move(Coord)
  public void move(float deltaX, float deltaY) {
    this.move(new Coord(deltaX, deltaY));
  }
  
  public void setPosition(Coord position) {
    Coord delta = position.minus(mPos);
    this.move(delta);
  }
  
  public void setPosition(float x, float y) {
    this.setPosition(new Coord(x, y));
  }
  
  public void grow(Coord delta) {
    mSize.plusEq(delta);
  }
  
  public void grow(float w, float h) {
    this.grow(new Coord(w, h));
  }
  
  public void setSize(Coord size) {
    Coord delta = size.minus(mSize);
    this.grow(delta);
  }
  
  public void setSize(float w, float h) {
    this.setSize(new Coord(w, h));
  }
  
  public void setFillColor(int fillColor) {
    mFillColor = fillColor;
  }
  
  public void setBorderColor(int borderColor) {
    mBorderColor = borderColor;
  }
  
  //Display object on screen
  public void show() {
    fill(mFillColor);
    stroke(mBorderColor);
    rect(mPos.x(), mPos.y(), mSize.x(), mSize.y());
  }
};
  public void settings() {  size(600, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "PokemonRivalockeTracker" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
